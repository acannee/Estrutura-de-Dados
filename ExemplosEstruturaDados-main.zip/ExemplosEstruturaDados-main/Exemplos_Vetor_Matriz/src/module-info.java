module Exemplos_Vetor {
}